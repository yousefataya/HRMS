﻿using Northwind.Core.Domain.Entities;
using Northwind.Core.Infra.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Northwind.Core.Domain.Repositories
{
    public interface IProductRepository 
    {
    }
}
