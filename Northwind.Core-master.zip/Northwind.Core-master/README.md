# Northwind.Core

This is an ASP.NET MVC Core sample application that uses the good old Microsoft Northwind database.

Technologies used

ASP.NET MVC Core<br />
Razor Pages<br />
Entity Framework Core<br />
Bootstrap<br />
JQuery<br />

In progress...
